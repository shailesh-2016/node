const router = require("express").Router();
const { Category } = require("../models/catModel");

router.get("/index", (req, res) => {
  res.render("pages/index");
});
router.get("/", (req, res) => {
  res.render("pages/login");
});
router.get("/register", (req, res) => {
  res.render("pages/register");
});

/// category /////
router.get("/addCategory", (req, res) => {
  res.render("pages/addCategory");
});
router.get("/viewCat", async (req, res) => {
  try {
    const categories = await Category.find();
    console.log(categories);
    res.render("pages/viewCat", { categories });
  } catch (error) {
    console.log("error: ", error);
  }
});
router.get("/updateCat", async (req, res) => {
  try {
    const { id } = req.params;
    const category = await Category.findById(id);
    res.render("pages/updateCat", { category });
  } catch (error) {
    console.log("error: ", error);
  }
});

module.exports = router;
